# Optical Wireless Communication 
## Handover Sceme Simulation
Handover Algorithm for mobile Access Points

### Instructions
0. Clone Repository
1. `python simulation.py`
2. `ctrl+C` to stop simulation
